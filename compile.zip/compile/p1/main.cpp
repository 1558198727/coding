
#include<stdio.h>

main()
{
    int a=9,b=20;
    printf("%d,%d",a--,--b);
}
