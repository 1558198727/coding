import java.io.*;

public class new_1{
	public static void main(String[] args){
		System.out.println("fdsfadf");
	}


}